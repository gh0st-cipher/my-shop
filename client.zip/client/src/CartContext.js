import { createContext, useContext, useState, useEffect } from "react";
import axios from "axios";

const CartContext = createContext();

export const CartProvider = ({ children }) => {
  const [cartItems, setCartItems] = useState([]);

  const token = localStorage.getItem("token");

  useEffect(() => {
    if (token) {
      axios.get("http://localhost:5000/api/cart", {
        headers: { Authorization: `Bearer ${token}` },
      })
      .then(res => setCartItems(res.data))
      .catch(err => console.error("Fetch cart failed", err));
    } else {
      // Load guest cart from localStorage
      let guestCart = JSON.parse(localStorage.getItem('guestCart') || '[]');
      setCartItems(
        guestCart.map(item => ({ productId: { _id: item.productId }, quantity: item.quantity }))
      );
    }
  }, [token]);

  const addToCart = (productId) => {
    if (!token) {
      // Guest cart: store in localStorage
      let guestCart = JSON.parse(localStorage.getItem('guestCart') || '[]');
      const exists = guestCart.find(item => item.productId === productId);
      if (exists) {
        guestCart = guestCart.map(item =>
          item.productId === productId
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      } else {
        guestCart.push({ productId, quantity: 1 });
      }
      localStorage.setItem('guestCart', JSON.stringify(guestCart));
      setCartItems(
        guestCart.map(item => ({ productId: { _id: item.productId }, quantity: item.quantity }))
      );
      return;
    }
    axios.post("http://localhost:5000/api/cart/add", { productId }, {
      headers: { Authorization: `Bearer ${token}` },
    })
    .then(() => {
      setCartItems(prev => {
        const exists = prev.find(item => item.productId._id === productId);
        if (exists) {
          return prev.map(item =>
            item.productId._id === productId
              ? { ...item, quantity: item.quantity + 1 }
              : item
          );
        }
        return [...prev, { productId: { _id: productId }, quantity: 1 }];
      });
    })
    .catch(err => console.error("Add to cart error", err));
  };

  const removeFromCart = (productId) => {
    if (!token) {
      // Guest cart: remove from localStorage
      let guestCart = JSON.parse(localStorage.getItem('guestCart') || '[]');
      guestCart = guestCart.filter(item => item.productId !== productId);
      localStorage.setItem('guestCart', JSON.stringify(guestCart));
      setCartItems(
        guestCart.map(item => ({ productId: { _id: item.productId }, quantity: item.quantity }))
      );
      return;
    }
    axios.post("http://localhost:5000/api/cart/remove", { productId }, {
      headers: { Authorization: `Bearer ${token}` },
    })
    .then(() => {
      setCartItems(prev => prev.filter(item => item.productId._id !== productId));
    })
    .catch(err => console.error("Remove from cart error", err));
  };

  return (
    <CartContext.Provider value={{ cartItems, addToCart, removeFromCart }}>
      {children}
    </CartContext.Provider>
  );
};

export const useCart = () => useContext(CartContext);

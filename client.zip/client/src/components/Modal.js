import React from "react";

const Modal = ({ show, onClose, children }) => {
  if (!show) return null;
  return (
    <div style={{
      position: 'fixed',
      inset: 0,
      margin: 0,
      width: '100vw',
      height: '100vh',
      background: 'rgba(0,0,0,0.5)',
      zIndex: 1000,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    }}>
      <div style={{
        background: '#18181b', color: '#fff', borderRadius: 12, padding: '2rem 2.5rem', minWidth: 320, boxShadow: '0 4px 32px #0008', textAlign: 'center', position: 'relative'
      }}>
        {children}
        <button onClick={onClose} style={{ marginTop: 24, background: '#22d3ee', color: '#18181b', border: 'none', borderRadius: 6, padding: '0.6rem 1.5rem', fontWeight: 700, fontSize: '1rem', cursor: 'pointer', boxShadow: '0 2px 8px #0ea5e9' }}>
          Close
        </button>
      </div>
    </div>
  );
};

export default Modal;

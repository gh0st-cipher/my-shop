import { Link, useNavigate } from 'react-router-dom';
import { FaUserCircle } from 'react-icons/fa';
import logo from '../images/logo.png';

function Navbar() {
  const isAdmin = localStorage.getItem("isAdmin") === "true";
  const isLoggedIn = !!localStorage.getItem("token");
  const navigate = useNavigate();

  function handleLogout() {
    localStorage.removeItem("token");
    localStorage.removeItem("isAdmin");
    localStorage.removeItem("user");
    navigate("/");
  }

  return (
    <nav className="navbar">
      <div style={{ display: 'flex', alignItems: 'center', gap: '0.7rem' }}>
        <img src={logo} alt="Logo" className="logo-img" style={{ width: 40, height: 40, borderRadius: 8 }} />
        <h2 style={{ margin: 0 }}>Gh0st Cipher</h2>
      </div>
      <div>
        <Link to="/">Home</Link>
        {!isAdmin && <Link to="/cart">Cart</Link>}
        {isAdmin && <Link to="/admin">Admin</Link>}
        {isAdmin && <Link to="/all-orders">All Orders</Link>}
        {!isLoggedIn && <Link to="/login">Login</Link>}
        {!isLoggedIn && <Link to="/register">Register</Link>}
        {isLoggedIn && !isAdmin && <Link to="/orders">My Orders</Link>}
        {isLoggedIn && !isAdmin && (
          <Link to="/profile" style={{ marginLeft: 10, verticalAlign: 'middle' }} title="Profile">
            <FaUserCircle size={32} style={{ borderRadius: '50%', background: '#e5e7eb', color: '#203a43' }} />
          </Link>
        )}
        {isLoggedIn && <button onClick={handleLogout}>Logout</button>}
      </div>
    </nav>
  );
}

export default Navbar;

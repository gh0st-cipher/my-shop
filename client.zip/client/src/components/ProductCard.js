import { useCart } from "../CartContext";

function ProductCard({ product }) {
  const { addToCart } = useCart();

  if (!product) {
    return null; // or show a fallback UI
  }

  return (
    <div className="product-card" style={{
      background: 'rgba(16,28,28,0.92)',
      borderRadius: 14,
      boxShadow: '0 0 18px #00ff90',
      padding: 18,
      textAlign: 'center',
      minHeight: 320,
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'space-between',
    }}>
      <img
        src={product.image}
        alt={product.name}
        style={{
          width: 120,
          height: 120,
          objectFit: 'contain',
          borderRadius: 10,
          marginBottom: 14,
          background: '#18181b',
        }}
        onError={e => { e.target.onerror = null; e.target.src = require('../images/logo.png'); }}
      />
      <h3 style={{ color: '#fff', fontWeight: 700, fontSize: 20, margin: '10px 0 6px 0', letterSpacing: 1, textShadow: '0 0 8px #00ff90' }}>{product.name}</h3>
      <p style={{ color: '#00ff90', fontWeight: 700, fontSize: 18, marginBottom: 12, textShadow: '0 0 8px #00ff90' }}>₹{product.price}</p>
      <button
        onClick={() => addToCart(product._id)}
        style={{
          background: '#00ff90',
          color: '#18181b',
          fontWeight: 700,
          border: 'none',
          borderRadius: 6,
          padding: '8px 18px',
          fontSize: 16,
          boxShadow: '0 0 8px #00ff90',
          fontFamily: 'Fira Mono, monospace',
          cursor: 'pointer',
          marginTop: 8,
        }}
      >
        Add to Cart
      </button>
    </div>
  );
}

export default ProductCard;

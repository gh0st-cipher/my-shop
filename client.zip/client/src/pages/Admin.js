import { useState, useEffect } from "react";
import axios from "axios";
import Modal from "../components/Modal";

function Admin() {
  const [products, setProducts] = useState([]);
  const [name, setName] = useState("");
  const [price, setPrice] = useState("");
  const [image, setImage] = useState("");
  const [editing, setEditing] = useState(null);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [deleteId, setDeleteId] = useState(null);
  const token = localStorage.getItem("token");

  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = () => {
    axios.get("http://localhost:5000/api/products")
      .then(res => setProducts(res.data))
      .catch(err => alert("Failed to fetch products"));
  };

  const handleAddOrEdit = (e) => {
    e.preventDefault();
    if (editing) {
      axios.put(`http://localhost:5000/api/products/${editing._id}`,
        { name, price, image },
        { headers: { Authorization: `Bearer ${token}` } }
      ).then(() => {
        setEditing(null); setName(""); setPrice(""); setImage(""); fetchProducts();
      }).catch(() => alert("Update failed"));
    } else {
      axios.post("http://localhost:5000/api/products",
        { name, price, image },
        { headers: { Authorization: `Bearer ${token}` } }
      ).then(() => {
        setName(""); setPrice(""); setImage(""); fetchProducts();
      }).catch(() => alert("Add failed (are you admin?)"));
    }
  };

  const handleEdit = (product) => {
    setEditing(product);
    setName(product.name);
    setPrice(product.price);
    setImage(product.image);
  };

  const openDeleteModal = (id) => {
    setDeleteId(id);
    setShowDeleteModal(true);
  };

  const handleDelete = () => {
    axios.delete(`http://localhost:5000/api/products/${deleteId}`,
      { headers: { Authorization: `Bearer ${token}` } }
    ).then(() => {
      setShowDeleteModal(false);
      fetchProducts();
    }).catch(() => alert("Delete failed"));
  };

  return (
    <div className="admin-container">
      <center><h1 style={{ color: "purple" }}>Admin Dashboard</h1></center>
      <form onSubmit={handleAddOrEdit}>
        <input value={name} onChange={e => setName(e.target.value)} placeholder="Name" required style={{ color: '#18181b' }} />
        <input value={price} onChange={e => setPrice(e.target.value)} placeholder="Price" type="number" required style={{ color: '#18181b' }} />
        <input value={image} onChange={e => setImage(e.target.value)} placeholder="Image URL" style={{ color: '#18181b' }} />
        <button type="submit" style={{ color: '#18181b' }}>{editing ? "Update" : "Add"} Product</button>
        {editing && <button type="button" style={{ color: '#18181b' }} onClick={() => { setEditing(null); setName(""); setPrice(""); setImage(""); }}>Cancel</button>}
      </form>
      <center><h1 style={{ color: "purple" }}>Products</h1></center>
      <ul>
        {products.map(p => (
          <li key={p._id} style={{ display: 'flex', alignItems: 'center', gap: '1rem', justifyContent: 'space-between' }}>
            <span style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
              <img src={p.image} alt={p.name} style={{ width: 50 }} />
              <span style={{ color: '#111', fontWeight: 'bold' }}>{p.name} - ₹{p.price}</span>
              {/* Add more product details here, e.g., stock */}
              {p.stock !== undefined && (
                <span style={{ color: '#22c55e', marginLeft: 12, fontWeight: 600 }}>
                  Stock: {p.stock}
                </span>
              )}
            </span>
            <span style={{ display: 'flex', gap: '0.5rem' }}>
              <button onClick={() => handleEdit(p)}>Edit</button>
              <button className="delete-btn" onClick={() => openDeleteModal(p._id)}>Delete</button>
            </span>
          </li>
        ))}
      </ul>
      <Modal show={showDeleteModal} onClose={() => setShowDeleteModal(false)}>
        <h2 style={{ color: '#ff1744', marginBottom: 16 }}>Delete Product</h2>
        <p style={{ fontSize: '1.1rem', color: '#fff', marginBottom: 0 }}>
          Are you sure you want to delete this product?
        </p>
        <div style={{ marginTop: 24, display: 'flex', justifyContent: 'center', gap: 16 }}>
          <button onClick={handleDelete} style={{ background: '#ef4444', color: '#fff', border: 'none', borderRadius: 6, padding: '0.6rem 1.5rem', fontWeight: 700, fontSize: '1rem', cursor: 'pointer', boxShadow: '0 2px 8px #e0e7ff' }}>Yes, Delete</button>
          <button onClick={() => setShowDeleteModal(false)} style={{ background: '#22d3ee', color: '#18181b', border: 'none', borderRadius: 6, padding: '0.6rem 1.5rem', fontWeight: 700, fontSize: '1rem', cursor: 'pointer', boxShadow: '0 2px 8px #0ea5e9' }}>No</button>
        </div>
      </Modal>
    </div>
  );
}

export default Admin;

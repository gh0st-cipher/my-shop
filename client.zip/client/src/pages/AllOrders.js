
import { useEffect, useState } from "react";
import axios from "axios";

function AllOrders() {
  const [orders, setOrders] = useState([]);
  const token = localStorage.getItem("token");
  const isAdmin = localStorage.getItem("isAdmin") === "true";

  useEffect(() => {
    if (!token || !isAdmin) return;
    axios.get("http://localhost:5000/api/orders/all", {
      headers: { Authorization: `Bearer ${token}` },
    })
      .then(res => setOrders(res.data))
      .catch(() => setOrders([]));
  }, [token, isAdmin]);

  if (!token || !isAdmin) return <div>Admin access required.</div>;

  const handleMarkDelivered = async (orderId) => {
    try {
      await axios.patch(`http://localhost:5000/api/orders/${orderId}/delivered`, {}, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setOrders(orders => orders.map(o => o._id === orderId ? { ...o, delivered: true } : o));
    } catch (err) {
      alert('Failed to update order status.');
    }
  };

  return (
    <div className="all-orders-container" style={{ maxWidth: 800, margin: '0 auto', padding: '2rem 1rem' }}>
      <h1 style={{ textAlign: 'center', color: '#203a43', marginBottom: '1.5rem', fontWeight: 700, letterSpacing: '1px' }}>
        All Orders {isAdmin ? '(Admin)' : ''}
      </h1>
      {orders.length === 0 ? (
        <p style={{ textAlign: 'center', color: '#64748b', fontSize: '1.1rem' }}>No orders found.</p>
      ) : (
        orders.map(order => (
          <div key={order._id} className="order-card" style={{ margin: '1.5rem 0', borderRadius: 10, boxShadow: '0 1px 6px rgba(30,41,59,0.06)', background: '#f1f5f9', padding: '1.2rem 1.5rem' }}>
            <h3 style={{ margin: 0, color: '#2563eb', fontWeight: 700, fontSize: '1.1rem', marginBottom: '0.5rem' }}>Order #{order._id}</h3>
            {isAdmin && (
              <p style={{ margin: 0, color: '#334155', fontSize: '1rem' }}>User: {order.user?.email || order.user?._id}</p>
            )}
            <p style={{ margin: 0, color: '#64748b', fontSize: '0.98rem' }}>Date: {new Date(order.createdAt).toLocaleString()}</p>
            <p style={{ margin: 0, color: '#64748b', fontSize: '0.98rem' }}>Address: {order.address}</p>
            <p style={{ margin: 0, color: '#64748b', fontSize: '0.98rem', marginBottom: '0.5rem' }}>Phone: {order.phone}</p>
            <ul style={{ margin: '0.5rem 0 0 1rem', color: '#203a43', fontSize: '0.98rem' }}>
              {order.products.map((item, idx) => (
                <li key={idx}>
                  {item.productId?.name || 'Product'} x {item.quantity}
                </li>
              ))}
            </ul>
            <div style={{ marginTop: 12 }}>
              <span style={{ color: order.delivered ? '#22c55e' : '#f59e42', fontWeight: 700, fontSize: '1rem' }}>
                {order.delivered ? 'Delivered' : 'Order will arrive soon'}
              </span>
              {isAdmin && !order.delivered && (
                <button
                  style={{ marginLeft: 16, background: '#22c55e', color: '#fff', border: 'none', borderRadius: 6, padding: '0.4rem 1.2rem', fontWeight: 700, fontSize: '1rem', cursor: 'pointer', boxShadow: '0 2px 8px #bbf7d0' }}
                  onClick={() => handleMarkDelivered(order._id)}
                >
                  Mark as Delivered
                </button>
              )}
            </div>
          </div>
        ))
      )}
    </div>
  );
}

export default AllOrders;


import { useCart } from "../CartContext";
import { useState } from "react";
import axios from "axios";
import Modal from "../components/Modal";

function Cart() {
  const { cartItems, removeFromCart } = useCart();
  const [showCheckout, setShowCheckout] = useState(false);
  const [address, setAddress] = useState("");
  const [phone, setPhone] = useState("");
  const [showModal, setShowModal] = useState(false);
  const [showLoginModal, setShowLoginModal] = useState(false);
  const isAdmin = localStorage.getItem("isAdmin") === "true";

  const handleCheckout = async (e) => {
    e.preventDefault();
    const token = localStorage.getItem("token");
    if (!token) {
      setShowLoginModal(true);
      return;
    }
    try {
      await axios.post(
        "http://localhost:5000/api/orders",
        {
          products: cartItems.map(item => ({
            productId: item.productId._id,
            quantity: item.quantity,
          })),
          address,
          phone,
        },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      setShowCheckout(false);
      setAddress("");
      setPhone("");
      setShowModal(true);
    } catch (err) {
      alert("Order failed! " + (err.response?.data?.error || ""));
    }
  };

  if (isAdmin) {
    return (
      <div className="cart-container" style={{ maxWidth: 700, margin: '0 auto', padding: '2rem 1rem', textAlign: 'center' }}>
        <h1 style={{ color: '#ff1744', marginBottom: '1.5rem', fontWeight: 700, letterSpacing: '1px' }}>Cart Disabled for Admins</h1>
        <p style={{ color: '#64748b', fontSize: '1.1rem' }}>Admins cannot place orders or use the cart.</p>
      </div>
    );
  }

  return (
    <div className="cart-container" style={{ maxWidth: 800, margin: '0 auto', padding: '2.5rem 1rem', fontFamily: 'Fira Mono, monospace', color: '#00ff90', background: 'transparent' }}>
      <h1 style={{ textAlign: 'center', color: '#00ff90', marginBottom: '2rem', fontWeight: 700, letterSpacing: '2px', textShadow: '0 0 8px #00ff90' }}>
        YOUR CART
      </h1>
      {cartItems.length === 0 ? (
        <p style={{ textAlign: 'center', color: '#22d3ee', fontSize: '1.1rem', textShadow: '0 0 6px #00ff90' }}>Cart is empty</p>
      ) : (
        cartItems.map((item) => (
          <div key={item.productId._id} className="order-card" style={{ margin: '1.2rem 0', borderRadius: 10, boxShadow: '0 0 12px #00ff90', background: 'rgba(20,30,30,0.95)', padding: '1.2rem 1.5rem', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <div>
              <h3 style={{ margin: 0, color: '#00ff90', fontWeight: 700, fontSize: '1.1rem', marginBottom: '0.5rem', textShadow: '0 0 6px #00ff90' }}>{item.productId.name}</h3>
              <p style={{ margin: 0, color: '#22d3ee', fontSize: '0.98rem', textShadow: '0 0 4px #00ff90' }}>Quantity: {item.quantity}</p>
            </div>
            <button onClick={() => removeFromCart(item.productId._id)} style={{ marginTop: 0, background: '#ff1744', color: '#fff', border: 'none', borderRadius: 6, padding: '8px 18px', fontWeight: 700, fontFamily: 'Fira Mono, monospace', boxShadow: '0 0 8px #ff1744', fontSize: 15 }}>Remove</button>
          </div>
        ))
      )}
      <button
        className="checkout-btn"
        disabled={cartItems.length === 0}
        onClick={() => setShowCheckout(true)}
        style={{ display: 'block', margin: '1.5rem auto 0 auto', minWidth: 160, background: '#00ff90', color: '#18181b', fontWeight: 700, border: 'none', borderRadius: 6, padding: '10px 0', fontSize: 17, letterSpacing: 1, boxShadow: '0 0 10px #00ff90', transition: 'background 0.2s' }}
      >
        Checkout
      </button>
      {showCheckout && (
        <form className="checkout-form" onSubmit={handleCheckout} style={{ marginTop: 20, background: 'rgba(20,30,30,0.95)', borderRadius: 12, boxShadow: '0 2px 16px #00ff90', padding: '2rem 2.2rem', maxWidth: 400, marginLeft: 'auto', marginRight: 'auto', border: '1.5px solid #00ff90' }}>
          <input
            type="text"
            placeholder="Address"
            value={address}
            onChange={e => setAddress(e.target.value)}
            required
            style={{ marginBottom: 18, background: '#18181b', color: '#00ff90', border: '1px solid #00ff90', borderRadius: 6, padding: '10px 12px', fontSize: 16, fontFamily: 'Fira Mono, monospace', boxShadow: '0 0 6px #00ff90' }}
          />
          <input
            type="text"
            placeholder="Phone"
            value={phone}
            onChange={e => setPhone(e.target.value)}
            required
            style={{ marginBottom: 18, background: '#18181b', color: '#00ff90', border: '1px solid #00ff90', borderRadius: 6, padding: '10px 12px', fontSize: 16, fontFamily: 'Fira Mono, monospace', boxShadow: '0 0 6px #00ff90' }}
          />
          <button type="submit" style={{ minWidth: 140, background: '#00ff90', color: '#18181b', fontWeight: 700, border: 'none', borderRadius: 6, padding: '10px 0', fontSize: 17, letterSpacing: 1, boxShadow: '0 0 10px #00ff90', transition: 'background 0.2s' }}>Place Order</button>
        </form>
      )}
      <Modal show={showModal} onClose={() => { setShowModal(false); window.location.reload(); }}>
        <h2 style={{ color: '#00ff90', marginBottom: 16, textShadow: '0 0 8px #00ff90' }}>Order Placed Successfully!</h2>
        <p style={{ fontSize: '1.1rem', color: '#fff', marginBottom: 0 }}>
          Your order has been placed successfully.<br />
          Our sales staff will contact you within 6 to 12 hours.<br />
          Thank you for shopping with us!
        </p>
      </Modal>
      <Modal show={showLoginModal} onClose={() => setShowLoginModal(false)}>
        <h2 style={{ color: '#ff1744', marginBottom: 16, textShadow: '0 0 8px #ff1744' }}>Login Required</h2>
        <p style={{ fontSize: '1.1rem', color: '#fff', marginBottom: 0 }}>
          Please <b>register</b> or <b>login</b> to checkout and place your order.<br />
          <span style={{ color: '#22d3ee' }}>You need an account to continue.</span>
        </p>
      </Modal>
    </div>
  );
}

export default Cart;

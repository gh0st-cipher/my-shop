import { useState, useEffect } from "react";
import ProductCard from "../components/ProductCard";
import axios from "axios";


function Home() {
  const [products, setProducts] = useState([]);
  const [page, setPage] = useState(1);
  const [productsPerPage] = useState(8);
  const [totalPages, setTotalPages] = useState(1);

  useEffect(() => {
    async function fetchProducts() {
      try {
        // Use the same base URL as other client code
        const res = await axios.get("http://localhost:5000/api/products");
        setProducts(res.data);
        setTotalPages(Math.ceil(res.data.length / productsPerPage));
      } catch (err) {
        setProducts([]);
        setTotalPages(1);
      }
    }
    fetchProducts();
  }, [productsPerPage]);

  const indexOfLastProduct = page * productsPerPage;
  const indexOfFirstProduct = indexOfLastProduct - productsPerPage;
  const currentProducts = products.slice(indexOfFirstProduct, indexOfLastProduct);

  return (
    <div
      style={{
        minHeight: '100vh',
        width: '100%',
        background: '#000',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        fontFamily: 'Fira Mono, monospace',
      }}
    >
      {/* Removed the large black neon box. Use a container for spacing if needed. */}
      <div style={{ width: '100%', maxWidth: 1200, margin: '48px 0 32px 0', display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
        <section
          className="hero"
          style={{
            textAlign: 'center',
            marginBottom: 36,
            width: '100%',
            maxWidth: 1100,
            marginLeft: 'auto',
            marginRight: 'auto',
            minHeight: 220,
            background: `url(${require('../images/small-background.jpg')}) center center/cover no-repeat`,
            borderRadius: 32,
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'start',
            gridAutoFlow: 'row dense',
            position: 'relative',
            boxShadow: '0 0 24px #00ff9044',
            overflow: 'hidden',
          }}
        >
          <div style={{
            background: 'rgba(0,0,0,0.55)',
            borderRadius: 24,
            padding: '24px 16px 16px 16px',
            display: 'inline-block',
            marginTop: 12,
          }}>
            <img src={require('../images/logo.png')} alt="Logo" style={{ width: 120, borderRadius: 16, marginBottom: 16, boxShadow: '0 0 16px #00ff90' }} />
            <h1 style={{ fontSize: '2.3rem', color: '#00ff90', fontWeight: 800, margin: '1rem 0 0.5rem 0', letterSpacing: '2px', textShadow: '0 0 12px #00ff90' }}>Gh0st's HackStore</h1>
            <p style={{ fontSize: '1.18rem', color: '#00ff90', marginBottom: '1.2rem', maxWidth: 600, marginLeft: 'auto', marginRight: 'auto', textShadow: '0 0 8px #00ff90' }}>
              Own made hacking gadgets and tools for pros and learners. <span style={{ color: '#22d3ee' }}>Fast shipping. Secure checkout!</span>
            </p>
          </div>
        </section>
        <h1 id="products" style={{ textAlign: 'center', color: '#22d3ee', margin: '2rem 0 1.5rem 0', fontWeight: 700, letterSpacing: '2px', textShadow: '0 0 8px #22d3ee' }}>Products</h1>
        <div
          className="home-container"
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))',
            gap: 40,
            alignItems: 'flex-start',
            width: '100%',
            maxWidth: 1700,
            background: 'rgba(24,24,27,0.92)',
            borderRadius: 32,
            padding: '40px 40px',
            boxShadow: '0 0 18px #7affd6',
          }}
        >
          {products.length === 0 ? (
            <p style={{ textAlign: 'center', color: '#22d3ee', fontSize: '1.1rem', width: '100%', textShadow: '0 0 6px #00ff90' }}>Loading products...</p>
          ) : (
            currentProducts.map((product, index) => (
              <div style={{ minWidth: 0, marginBottom: 20, width: '100%', display: 'flex', justifyContent: 'center' }} key={product._id || index}>
                <ProductCard product={product} />
              </div>
            ))
          )}
        </div>
        <div style={{ textAlign: 'center', marginTop: '2.5rem' }}>
          <button
            onClick={() => setPage(page - 1)}
            disabled={page === 1}
            style={{ marginRight: 10, background: '#00ff90', color: '#18181b', fontWeight: 700, border: 'none', borderRadius: 6, padding: '8px 18px', fontSize: 16, boxShadow: '0 0 8px #00ff90', fontFamily: 'Fira Mono, monospace', cursor: 'pointer' }}
          >
            Previous
          </button>
          <span style={{ fontWeight: 700, color: '#22d3ee', textShadow: '0 0 6px #00ff90', fontSize: 17, margin: '0 12px' }}>
            Page {page} of {totalPages}
          </span>
          <button
            onClick={() => setPage(page + 1)}
            disabled={page === totalPages}
            style={{ marginLeft: 10, background: '#00ff90', color: '#18181b', fontWeight: 700, border: 'none', borderRadius: 6, padding: '8px 18px', fontSize: 16, boxShadow: '0 0 8px #00ff90', fontFamily: 'Fira Mono, monospace', cursor: 'pointer' }}
          >
            Next
          </button>
        </div>
      </div>
    </div>
  );
}

export default Home;

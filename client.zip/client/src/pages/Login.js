import { useState } from "react";
import axios from "axios";
import Modal from "../components/Modal";


function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showModal, setShowModal] = useState(false);
  const [showErrorModal, setShowErrorModal] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post("http://localhost:5000/api/auth/login", {
        email,
        password
      });

      localStorage.setItem("token", res.data.token);
      localStorage.setItem("user", JSON.stringify(res.data.user));
      localStorage.setItem("isAdmin", res.data.user.isAdmin ? "true" : "false");
      setShowModal(true);
      setTimeout(() => {
        window.location.href = "/";
      }, 1500);
    } catch (err) {
      setErrorMsg(err.response?.data?.error || "Invalid id or password");
      setShowErrorModal(true);
    }
  };

  return (
    <div className="home-container" style={{ maxWidth: 420, margin: '0 auto', padding: '2.5rem 1rem', fontFamily: 'Fira Mono, monospace', background: 'transparent' }}>
      <h1 style={{ textAlign: 'center', color: '#00ff90', marginBottom: '2rem', fontWeight: 700, letterSpacing: '2px', textShadow: '0 0 8px #00ff90' }}>
        LOGIN
      </h1>
      <form onSubmit={handleSubmit} className="form-container" style={{ background: 'rgba(20,30,30,0.95)', borderRadius: 12, boxShadow: '0 2px 16px #00ff90', padding: '2rem 2.2rem', border: '1.5px solid #00ff90' }}>
        <input
          type="email"
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
          style={{ marginBottom: 18, background: '#18181b', color: '#00ff90', border: '1px solid #00ff90', borderRadius: 6, padding: '10px 12px', fontSize: 16, fontFamily: 'Fira Mono, monospace', boxShadow: '0 0 6px #00ff90' }}
        />
        <input
          type="password"
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
          style={{ marginBottom: 18, background: '#18181b', color: '#00ff90', border: '1px solid #00ff90', borderRadius: 6, padding: '10px 12px', fontSize: 16, fontFamily: 'Fira Mono, monospace', boxShadow: '0 0 6px #00ff90' }}
        />
        <button type="submit" style={{ minWidth: 140, margin: '0 auto', display: 'block', background: '#00ff90', color: '#18181b', fontWeight: 700, border: 'none', borderRadius: 6, padding: '10px 0', fontSize: 17, letterSpacing: 1, boxShadow: '0 0 10px #00ff90', transition: 'background 0.2s' }}>Login</button>
      </form>
      <Modal show={showModal} onClose={() => setShowModal(false)}>
        <h2 style={{ color: '#00ff90', marginBottom: 16, textShadow: '0 0 8px #00ff90' }}>Login Successful!</h2>
        <p style={{ fontSize: '1.1rem', color: '#fff', marginBottom: 0 }}>
          Welcome back! Redirecting to homepage...
        </p>
      </Modal>
      <Modal show={showErrorModal} onClose={() => setShowErrorModal(false)}>
        <h2 style={{ color: '#ff1744', marginBottom: 16 }}>Invalid ID or Password</h2>
        <p style={{ fontSize: '1.1rem', color: '#fff', marginBottom: 0 }}>
          {errorMsg}
        </p>
      </Modal>
    </div>
  );
}

export default Login;

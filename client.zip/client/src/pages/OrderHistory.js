
import { useEffect, useState } from "react";
import axios from "axios";
import Modal from "../components/Modal";

function OrderHistory() {
  const [orders, setOrders] = useState([]);
  const [showCancelModal, setShowCancelModal] = useState(false);
  const [cancelOrderId, setCancelOrderId] = useState(null);
  const [cancelError, setCancelError] = useState("");
  const token = localStorage.getItem("token");

  useEffect(() => {
    if (!token) return;
    axios.get("http://localhost:5000/api/orders", {
      headers: { Authorization: `Bearer ${token}` },
    })
      .then(res => setOrders(res.data))
      .catch(() => setOrders([]));
  }, [token]);

  if (!token) return <div>Please login to view your orders.</div>;

  function openCancelModal(orderId) {
    setCancelOrderId(orderId);
    setShowCancelModal(true);
    setCancelError("");
  }

  async function handleCancel() {
    try {
      await axios.delete(`http://localhost:5000/api/orders/${cancelOrderId}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setOrders(orders.filter(order => order._id !== cancelOrderId));
      setShowCancelModal(false);
    } catch (err) {
      setCancelError('Failed to cancel order.');
    }
  }

  return (
    <div className="order-history-container" style={{ maxWidth: 1200, margin: '0 auto', padding: '2.5rem 1.5rem' }}>
      <h1 style={{ textAlign: 'center', color: '#ff1744', marginBottom: '1.5rem', fontWeight: 700, letterSpacing: '1px' }}>
        Your Orders
      </h1>
      {orders.length === 0 ? (
        <p style={{ textAlign: 'center', color: '#64748b', fontSize: '1.1rem' }}>No orders found.</p>
      ) : (
        orders.map(order => (
          <div key={order._id} className="order-card" style={{ margin: '1.5rem 0', borderRadius: 10, boxShadow: '0 1px 6px rgba(30,41,59,0.06)', background: '#f1f5f9', padding: '1.2rem 1.5rem' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
              <span style={{ color: '#2563eb', fontWeight: 800, fontSize: '1.15rem', letterSpacing: '0.5px', fontFamily: 'Montserrat, Segoe UI, Arial, sans-serif' }}>
                Order #{order._id.slice(-6).toUpperCase()}
              </span>
              {!order.delivered && (
                <button
                  className="delete-btn"
                  style={{ background: '#ef4444', color: '#fff', border: 'none', borderRadius: 6, padding: '0.4rem 1rem', fontWeight: 700, fontFamily: 'Montserrat, Segoe UI, Arial, sans-serif', cursor: 'pointer', fontSize: '0.98rem', boxShadow: '0 2px 8px #e0e7ff', transition: 'background 0.2s' }}
                  onClick={() => openCancelModal(order._id)}
                >
                  Cancel Order
                </button>
              )}
            </div>
            <p style={{ margin: 0, color: '#64748b', fontSize: '1rem', fontWeight: 600 }}>Date: {new Date(order.createdAt).toLocaleString()}</p>
            <p style={{ margin: 0, color: '#64748b', fontSize: '1rem', fontWeight: 600 }}>Address: {order.address}</p>
            <p style={{ margin: 0, color: '#64748b', fontSize: '1rem', fontWeight: 600, marginBottom: '0.5rem' }}>Phone: {order.phone}</p>
            <ul style={{ margin: '0.5rem 0 0 1rem', color: '#203a43', fontSize: '1rem', fontWeight: 600, fontFamily: 'Montserrat, Segoe UI, Arial, sans-serif' }}>
              {order.products.map((item, idx) => (
                <li key={idx}>
                  {item.productId?.name || 'Product'} x {item.quantity}
                </li>
              ))}
            </ul>
            <div style={{ marginTop: 12 }}>
              <span style={{ color: order.delivered ? '#22c55e' : '#f59e42', fontWeight: 700, fontSize: '1rem' }}>
                {order.delivered ? 'Delivered' : 'Order will arrive soon'}
              </span>
            </div>
          </div>
        ))
      )}
      <Modal show={showCancelModal} onClose={() => setShowCancelModal(false)}>
        <h2 style={{ color: '#ff1744', marginBottom: 16 }}>Cancel Order</h2>
        <p style={{ fontSize: '1.1rem', color: '#fff', marginBottom: 0 }}>
          Are you sure you want to cancel this order?
        </p>
        {cancelError && <p style={{ color: '#ef4444', marginTop: 8 }}>{cancelError}</p>}
        <div style={{ marginTop: 24, display: 'flex', justifyContent: 'center', gap: 16 }}>
          <button onClick={handleCancel} style={{ background: '#ef4444', color: '#fff', border: 'none', borderRadius: 6, padding: '0.6rem 1.5rem', fontWeight: 700, fontSize: '1rem', cursor: 'pointer', boxShadow: '0 2px 8px #e0e7ff' }}>Yes, Cancel</button>
          <button onClick={() => setShowCancelModal(false)} style={{ background: '#22d3ee', color: '#18181b', border: 'none', borderRadius: 6, padding: '0.6rem 1.5rem', fontWeight: 700, fontSize: '1rem', cursor: 'pointer', boxShadow: '0 2px 8px #0ea5e9' }}>No</button>
        </div>
      </Modal>
    </div>
  );
}

export default OrderHistory;

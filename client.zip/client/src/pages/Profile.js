import { useEffect, useState } from "react";
import Modal from "../components/Modal";
import { FaUserCircle } from 'react-icons/fa';
import axios from "axios";

function Profile() {
  const [user, setUser] = useState(null);
  const [modal, setModal] = useState({ show: false, message: "" });

  useEffect(() => {
    const token = localStorage.getItem("token");
    if (!token) {
      setModal({ show: true, message: "Please login to view your profile. (No token)" });
      return;
    }
    axios.get("http://localhost:5000/api/user/me", {
      headers: { Authorization: `Bearer ${token}` }
    })
      .then(res => setUser(res.data))
      .catch(err => {
        setModal({
          show: true,
          message: `Failed to fetch user details.\nToken: ${token}\nError: ${err.response?.data?.error || err.message}`
        });
      });
  }, []);

  if (!user) {
    return (
      <Modal show={modal.show} onClose={() => setModal({ show: false, message: "" })}>
        <div style={{ padding: 20, textAlign: 'center', fontWeight: 600 }}>{modal.message}</div>
      </Modal>
    );
  }

  return (
    <div className="home-container" style={{
      maxWidth: 700,
      margin: '48px auto 32px auto',
      padding: '2.5rem 2rem',
      fontFamily: 'Fira Mono, monospace',
      color: '#00ff90',
      background: 'linear-gradient(135deg, #101c1c 60%, #0a2a1a 100%)',
      borderRadius: 18,
      boxShadow: '0 0 32px #00ff90',
    }}>
      <h1 style={{ textAlign: 'center', color: '#00ff90', marginBottom: '2.5rem', fontWeight: 700, letterSpacing: '2px', textShadow: '0 0 8px #00ff90' }}>
        <FaUserCircle size={60} style={{ verticalAlign: 'middle', marginRight: 12, color: '#00ff90', filter: 'drop-shadow(0 0 6px #00ff90)' }} />
        YOUR PROFILE
      </h1>
      <div style={{ display: 'flex', justifyContent: 'center', gap: 60, alignItems: 'flex-start', marginTop: 20 }}>
        <div style={{ minWidth: 180 }}>
          <div style={{ marginBottom: 18, fontWeight: 700, color: '#00ff90', letterSpacing: 1 }}>Name:</div>
          <div style={{ marginBottom: 18, fontWeight: 700, color: '#00ff90', letterSpacing: 1 }}>Age:</div>
          <div style={{ marginBottom: 18, fontWeight: 700, color: '#00ff90', letterSpacing: 1 }}>Email:</div>
          <div style={{ marginBottom: 18, fontWeight: 700, color: '#00ff90', letterSpacing: 1 }}>Phone:</div>
          <div style={{ marginBottom: 18, fontWeight: 700, color: '#00ff90', letterSpacing: 1 }}>Address:</div>
          <div style={{ marginBottom: 18, fontWeight: 700, color: '#00ff90', letterSpacing: 1 }}>Street:</div>
          <div style={{ marginBottom: 18, fontWeight: 700, color: '#00ff90', letterSpacing: 1 }}>State:</div>
        </div>
        <div style={{ minWidth: 260 }}>
          <div style={{ marginBottom: 18, color: '#fff', fontWeight: 600, textShadow: '0 0 6px #00ff90' }}>{user.name}</div>
          <div style={{ marginBottom: 18, color: '#fff', fontWeight: 600, textShadow: '0 0 6px #00ff90' }}>{user.age}</div>
          <div style={{ marginBottom: 18, color: '#fff', fontWeight: 600, textShadow: '0 0 6px #00ff90' }}>{user.email}</div>
          <div style={{ marginBottom: 18, color: '#fff', fontWeight: 600, textShadow: '0 0 6px #00ff90' }}>{user.phone}</div>
          <div style={{ marginBottom: 18, color: '#fff', fontWeight: 600, textShadow: '0 0 6px #00ff90' }}>{user.address}</div>
          <div style={{ marginBottom: 18, color: '#fff', fontWeight: 600, textShadow: '0 0 6px #00ff90' }}>{user.street}</div>
          <div style={{ marginBottom: 18, color: '#fff', fontWeight: 600, textShadow: '0 0 6px #00ff90' }}>{user.state}</div>
        </div>
      </div>
    </div>
  );
}

export default Profile;

import { useState } from "react";
import Modal from "../components/Modal";
import axios from "axios";
import { useNavigate } from "react-router-dom";

function Register() {
  const [name, setName] = useState("");
  const [age, setAge] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [address, setAddress] = useState("");
  const [street, setStreet] = useState("");
  const [state, setState] = useState("");
  const [phone, setPhone] = useState("");
  const navigate = useNavigate();
  const [modal, setModal] = useState({ show: false, message: "" });

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.post("http://localhost:5000/api/auth/register", {
        name,
        age,
        email,
        password,
        address,
        phone,
        street,
        state
      });
      setModal({ show: true, message: "Registration successful! Please login." });
      setTimeout(() => {
        setModal({ show: false, message: "" });
        navigate("/login");
      }, 1500);
    } catch (err) {
      const msg = err.response?.data?.error || "Registration failed!";
      setModal({ show: true, message: msg });
    }
  };

  return (
    <div className="home-container" style={{ maxWidth: 420, margin: '0 auto', padding: '2.5rem 1rem', fontFamily: 'Fira Mono, monospace', background: 'transparent' }}>
      <h1 style={{ textAlign: 'center', color: '#00ff90', marginBottom: '2rem', fontWeight: 700, letterSpacing: '2px', textShadow: '0 0 8px #00ff90' }}>
        REGISTER
      </h1>
      <form onSubmit={handleSubmit} className="form-container" style={{ background: 'rgba(20,30,30,0.95)', borderRadius: 12, boxShadow: '0 2px 16px #00ff90', padding: '2rem 2.2rem', border: '1.5px solid #00ff90' }}>
        <div style={{ display: 'flex', gap: 18, flexWrap: 'wrap', justifyContent: 'space-between' }}>
          <div style={{ flex: 1, minWidth: 180, display: 'flex', flexDirection: 'column', gap: 18 }}>
            <input type="text" placeholder="Name" value={name} onChange={(e) => setName(e.target.value)} required style={{ background: '#18181b', color: '#00ff90', border: '1px solid #00ff90', borderRadius: 6, padding: '10px 12px', fontSize: 16, fontFamily: 'Fira Mono, monospace', boxShadow: '0 0 6px #00ff90' }} />
            <input type="email" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} required style={{ background: '#18181b', color: '#00ff90', border: '1px solid #00ff90', borderRadius: 6, padding: '10px 12px', fontSize: 16, fontFamily: 'Fira Mono, monospace', boxShadow: '0 0 6px #00ff90' }} />
            <input type="text" placeholder="Address" value={address} onChange={(e) => setAddress(e.target.value)} required style={{ background: '#18181b', color: '#00ff90', border: '1px solid #00ff90', borderRadius: 6, padding: '10px 12px', fontSize: 16, fontFamily: 'Fira Mono, monospace', boxShadow: '0 0 6px #00ff90' }} />
            <input type="text" placeholder="State" value={state} onChange={(e) => setState(e.target.value)} required style={{ background: '#18181b', color: '#00ff90', border: '1px solid #00ff90', borderRadius: 6, padding: '10px 12px', fontSize: 16, fontFamily: 'Fira Mono, monospace', boxShadow: '0 0 6px #00ff90' }} />
          </div>
          <div style={{ flex: 1, minWidth: 180, display: 'flex', flexDirection: 'column', gap: 18 }}>
            <input type="number" placeholder="Age" value={age} onChange={(e) => setAge(e.target.value)} required style={{ background: '#18181b', color: '#00ff90', border: '1px solid #00ff90', borderRadius: 6, padding: '10px 12px', fontSize: 16, fontFamily: 'Fira Mono, monospace', boxShadow: '0 0 6px #00ff90' }} />
            <input type="text" placeholder="Street" value={street} onChange={(e) => setStreet(e.target.value)} required style={{ background: '#18181b', color: '#00ff90', border: '1px solid #00ff90', borderRadius: 6, padding: '10px 12px', fontSize: 16, fontFamily: 'Fira Mono, monospace', boxShadow: '0 0 6px #00ff90' }} />
            <input type="text" placeholder="Phone Number" value={phone} onChange={(e) => setPhone(e.target.value)} required style={{ background: '#18181b', color: '#00ff90', border: '1px solid #00ff90', borderRadius: 6, padding: '10px 12px', fontSize: 16, fontFamily: 'Fira Mono, monospace', boxShadow: '0 0 6px #00ff90' }} />
            <input type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} required style={{ background: '#18181b', color: '#00ff90', border: '1px solid #00ff90', borderRadius: 6, padding: '10px 12px', fontSize: 16, fontFamily: 'Fira Mono, monospace', boxShadow: '0 0 6px #00ff90' }} />
          </div>
        </div>
        <button type="submit" style={{ minWidth: 140, margin: '2rem auto 0 auto', display: 'block', background: '#00ff90', color: '#18181b', fontWeight: 700, border: 'none', borderRadius: 6, padding: '10px 0', fontSize: 17, letterSpacing: 1, boxShadow: '0 0 10px #00ff90', transition: 'background 0.2s' }}>Register</button>
      </form>
      <Modal show={modal.show} onClose={() => setModal({ show: false, message: "" })}>
        <div style={{ padding: 20, textAlign: 'center', fontWeight: 600, color: '#00ff90', textShadow: '0 0 8px #00ff90' }}>{modal.message}</div>
      </Modal>
    </div>
  );
}

export default Register;

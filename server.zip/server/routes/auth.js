const express = require("express");
const router = express.Router();
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const User = require("../models/User");

// Register Route
router.post("/register", async (req, res) => {
  try {
    const { name, age, email, password, address, phone, street, state } = req.body;
    if (!name || !age || !email || !password || !address || !phone || !street || !state) {
      return res.status(400).json({ error: "All fields are required." });
    }
    // Check if user already exists
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(409).json({ error: "User with this email already exists. Please login." });
    }
    const hashedPassword = await bcrypt.hash(password, 10);
    const newUser = new User({ name, age, email, password: hashedPassword, address, phone, street, state });
    await newUser.save();
    res.status(201).json({ message: "User registered successfully!" });
  } catch (err) {
    res.status(500).json({ error: "Registration failed!" });
  }
});

router.post("/login", async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email });

    if (!user) return res.status(404).json({ error: "User not found!" });

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) return res.status(400).json({ error: "Invalid password!" });

    const token = jwt.sign({ id: user._id, isAdmin: user.isAdmin }, process.env.JWT_SECRET, {
      expiresIn: "1h",
    });

    res.json({
      message: "Login successful!",
      token,
      user: {
        name: user.name,
        age: user.age,
        email: user.email,
        address: user.address,
        phone: user.phone,
        street: user.street,
        state: user.state,
        isAdmin: user.isAdmin
      }
    });
  } catch (err) {
    res.status(500).json({ error: "Login failed!" });
  }
});

module.exports = router;

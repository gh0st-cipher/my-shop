const express = require("express");
const router = express.Router();
const User = require("../models/User");
const Product = require("../models/Product");
const jwt = require("jsonwebtoken");

function authMiddleware(req, res, next) {
  const token = req.headers.authorization?.split(" ")[1];
  if (!token) return res.status(401).json({ error: "Unauthorized!" });

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded;
    next();
  } catch {
    res.status(401).json({ error: "Invalid token!" });
  }
}

router.get("/", authMiddleware, async (req, res) => {
  const user = await User.findById(req.user.id).populate("cart.productId");
  res.json(user.cart);
});

router.post("/add", authMiddleware, async (req, res) => {
  const { productId } = req.body;
  const user = await User.findById(req.user.id);

  const existingItem = user.cart.find((item) =>
    item.productId.toString() === productId
  );

  if (existingItem) {
    existingItem.quantity += 1;
  } else {
    user.cart.push({ productId, quantity: 1 });
  }

  await user.save();
  res.json({ message: "Cart updated!" });
});

router.post("/remove", authMiddleware, async (req, res) => {
  const { productId } = req.body;
  const user = await User.findById(req.user.id);

  user.cart = user.cart.filter((item) =>
    item.productId.toString() !== productId
  );

  await user.save();
  res.json({ message: "Item removed from cart!" });
});

module.exports = router;

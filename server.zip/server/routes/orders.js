
const express = require("express");
const router = express.Router();
const Order = require("../models/Order");

const { authenticate, requireAdmin } = require("../middleware/auth");
const { sendOrderNotification } = require("../utils/mailer");

router.patch('/:id/delivered', authenticate, requireAdmin, async (req, res) => {
  try {
    const order = await Order.findById(req.params.id);
    if (!order) return res.status(404).json({ error: 'Order not found' });
    order.delivered = true;
    await order.save();
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: 'Failed to update order status' });
  }
});

router.post("/", authenticate, async (req, res) => {
  try {
    const { products, address, phone } = req.body;
    const order = new Order({
      user: req.user._id,
      products,
      address,
      phone,
    });
    await order.save();

    const populatedOrder = await Order.findById(order._id)
      .populate('user', 'name')
      .populate('products.productId', 'name');

    const productsString = populatedOrder.products
      .map(p => {
        const prodName = p.productId && p.productId.name ? p.productId.name : p.productId;
        return `${prodName} (${p.productId?._id || p.productId}) x${p.quantity}`;
      })
      .join(', ');

    try {
      await sendOrderNotification({
        to: 'cyberexpertranjith@gmail.com',
        subject: 'New Order Received',
        text: `A new order has been placed.\nOrder ID: ${populatedOrder._id}\nUser ID: ${populatedOrder.user._id}\nCustomer Name: ${populatedOrder.user.name}\nAddress: ${populatedOrder.address}\nPhone: ${populatedOrder.phone}\nProducts: ${productsString}`
      });
    } catch (mailErr) {
      console.error('Order email failed:', mailErr);
    }

    const User = require("../models/User");
    await User.findByIdAndUpdate(req.user._id, { $set: { cart: [] } });
    res.status(201).json(order);
  } catch (err) {
    res.status(500).json({ error: "Failed to create order" });
  }
});

router.get("/", authenticate, async (req, res) => {
  try {
    const orders = await Order.find({ user: req.user._id }).populate("products.productId");
    res.json(orders);
  } catch (err) {
    res.status(500).json({ error: "Failed to fetch orders" });
  }
});

router.get("/all", authenticate, requireAdmin, async (req, res) => {
  try {
    const orders = await Order.find().populate("user").populate("products.productId");
    res.json(orders);
  } catch (err) {
    res.status(500).json({ error: "Failed to fetch all orders" });
  }
});


router.delete('/:id', authenticate, async (req, res) => {
  try {
    const order = await Order.findOne({ _id: req.params.id, user: req.user._id });
    if (!order) return res.status(404).json({ error: 'Order not found' });
    await order.deleteOne();
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: 'Failed to cancel order' });
  }
});

module.exports = router;

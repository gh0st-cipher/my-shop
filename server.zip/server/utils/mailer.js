const nodemailer = require('nodemailer');

const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.MAIL_USER,
    pass: process.env.MAIL_PASS
  }
});

const ADMIN_EMAIL = process.env.ADMIN_EMAIL;

function sendOrderNotification({ subject, text }) {
  const mailOptions = {
    from: process.env.MAIL_USER,
    to: ADMIN_EMAIL,
    subject,
    text
  };
  return transporter.sendMail(mailOptions);
}

module.exports = { sendOrderNotification };
